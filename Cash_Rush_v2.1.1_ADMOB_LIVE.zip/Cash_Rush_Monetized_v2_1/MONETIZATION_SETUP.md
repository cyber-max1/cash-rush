# Cash Rush — монетизація v2.1

## Що вже інтегровано
- Google Mobile Ads SDK 25.4.0.
- Тестовий banner ad.
- Тестовий rewarded ad.
- Reward за повний rewarded ad: x2 на 30 секунд.
- Android bridge між Java та грою.
- Кнопки реклами в грі.
- Окремий production-ready блок для заміни TEST IDs.

Google прямо рекомендує використовувати тестові ad unit IDs під час розробки; використання live-реклами для тестування може призвести до проблем з акаунтом. Після створення власного AdMob app та ad units потрібно замінити IDs.

## Що потрібно зробити власнику гри
1. Створити/підключити власний AdMob акаунт.
2. Зареєструвати Cash Rush як Android app.
3. Створити Banner ad unit і Rewarded ad unit.
4. Замінити:
   - APPLICATION_ID у AndroidManifest.xml
   - REWARDED_TEST_ID у MainActivity.java
   - banner ad unit ID у MainActivity.java
5. Створити Google Play Console developer account і опублікувати/тестувати застосунок.
6. Заповнити privacy/data safety та інші обов'язкові дані Google Play.
7. Після схвалення live ads почнуть приносити рекламний дохід; виплати залежать від показів, країни, попиту та порогів AdMob.

## Важливо
Я не можу створити AdMob/Play Console акаунт замість власника, пройти його ідентифікацію або прив'язати банківські реквізити. Це потрібно зробити власнику акаунта.

## Безкоштовна розробка
Поки ми тестуємо, використовуються Google TEST IDs. Це не приносить реального доходу. Реальний дохід починається тільки після підключення власних live ad units та публікації/розповсюдження гри.
