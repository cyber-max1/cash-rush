# Cash Rush — збірка APK

## Найпростіше
Відкрий папку проєкту в Android Studio та запусти:
`app > build > assembleDebug`

Готовий APK буде:
`app/build/outputs/apk/debug/app-debug.apk`

## Без встановлення Android Studio
Можна завантажити цей проєкт у власний GitHub-репозиторій і запустити
Actions → Build Cash Rush APK → Run workflow.
Workflow сам встановить Android SDK/Gradle та збере APK.

## Важливо
APK, який можна одразу встановити на телефон, не був скомпільований у цьому
середовищі, бо тут відсутні Android SDK і Gradle. Я не видаю ZIP-проєкт за APK.
