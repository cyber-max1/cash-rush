# Cash Rush — Privacy Policy

Last updated: 2026-09-08

Cash Rush may use Google Mobile Ads to display advertisements, including rewarded ads and banner ads.

Advertising providers may process device and advertising information as described in their own privacy documentation. The game itself stores gameplay progress and settings locally on the user's device.

The developer should publish this policy at a publicly accessible URL before production distribution and complete the applicable Google Play Data safety and consent requirements.

Contact: [ADD YOUR CONTACT EMAIL]
