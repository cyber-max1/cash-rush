# Cash Rush v2.1 — Monetized Android

This build adds Google Mobile Ads integration using official Google TEST ad units.

Test:
- Banner: `ca-app-pub-3940256099942544/6300978111`
- Rewarded: `ca-app-pub-3940256099942544/5224354917`
- App ID: `ca-app-pub-3940256099942544~3347511713`

Do NOT publish with test IDs. Replace them with your own AdMob IDs before production.

The app currently rewards a completed rewarded ad with 30 seconds of x2 income.

See `MONETIZATION_SETUP.md` and `PRIVACY_POLICY.md`.
