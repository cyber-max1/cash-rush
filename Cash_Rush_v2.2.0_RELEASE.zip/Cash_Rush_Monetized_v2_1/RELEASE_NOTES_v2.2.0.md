# Cash Rush v2.2.0 — Google Play release preparation

- Target SDK 36 / Android 16 requirement
- Version code 6, version name 2.2.0
- Release build uses the real Cash Rush AdMob banner and rewarded ad units
- Debug build continues to use Google test ad units
- Release workflow builds an Android App Bundle (AAB)

## Important
This source is prepared for release, but Play Store upload signing must be configured with an upload keystore before production upload. Do not commit keystore files or passwords to the repository.
