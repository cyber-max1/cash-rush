# Cash Rush v2.1.2 — ad loading fix

The debug APK uses Google test ad units, so the rewarded ad can be tested before the AdMob app is published/reviewed.

- Debug banner: Google test ID
- Debug rewarded: Google test ID
- Release banner/rewarded: the project's production AdMob IDs
- Ad loading now starts after Mobile Ads SDK initialization

Do not click production ads yourself.
