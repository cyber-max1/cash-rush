package com.cashrush.game;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.FrameLayout;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.rewarded.RewardItem;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.LoadAdError;

public class MainActivity extends Activity {
    private WebView webView;
    private AdView banner;
    private RewardedAd rewardedAd;


    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        MobileAds.initialize(this, status -> {
            loadBanner();
            loadRewarded();
        });

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF06101D);

        FrameLayout gameFrame = new FrameLayout(this);
        webView = new WebView(this);
        webView.setBackgroundColor(0xFF06101D);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);

        webView.addJavascriptInterface(new GameBridge(), "Android");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);

        gameFrame.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        root.addView(gameFrame, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        banner = new AdView(this);
        banner.setAdSize(AdSize.BANNER);
        banner.setAdUnitId(BuildConfig.BANNER_AD_UNIT_ID);
        root.addView(banner, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        setContentView(root);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void loadBanner() {
        if (banner != null) {
            banner.loadAd(new AdRequest.Builder().build());
        }
    }

    private void loadRewarded() {
        AdRequest request = new AdRequest.Builder().build();
        RewardedAd.load(this, BuildConfig.REWARDED_AD_UNIT_ID, request,
                new RewardedAdLoadCallback() {
                    @Override public void onAdLoaded(RewardedAd ad) {
                        rewardedAd = ad;
                        rewardedAd.setFullScreenContentCallback(
                            new FullScreenContentCallback() {
                                @Override public void onAdDismissedFullScreenContent() {
                                    rewardedAd = null;
                                    loadRewarded();
                                }
                                @Override public void onAdFailedToShowFullScreenContent(AdError error) {
                                    rewardedAd = null;
                                    loadRewarded();
                                }
                            });
                    }
                    @Override public void onAdFailedToLoad(LoadAdError error) {
                        rewardedAd = null;
                    }
                });
    }

    public class GameBridge {
        @JavascriptInterface
        public void showRewardedAd() {
            runOnUiThread(() -> {
                if (rewardedAd == null) {
                    webView.evaluateJavascript(
                        "window.adUnavailable && window.adUnavailable()", null);
                    loadRewarded();
                    return;
                }
                rewardedAd.show(MainActivity.this, rewardItem -> {
                    webView.evaluateJavascript(
                        "window.rewardFromAd && window.rewardFromAd()", null);
                });
            });
        }
    }

    @Override protected void onDestroy() {
        if (banner != null) banner.destroy();
        if (webView != null) webView.destroy();
        super.onDestroy();
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
